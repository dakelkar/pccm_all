import pandas as pd
import os
import sqlite3
from modules.ask_y_n_statement import ask_option, ask_y_n
from datetime import date
from modules.pccm_names import db_tables
from sql.add_update_sql import table_check
import modules.table_dicts as table_dicts

def output_data():
    data_location_name = ['D:/repos/pccm_db/main/DB/from_linux', "PCCM_BreastCancerDB_all_data.db",
                          'D:/repos/pccm_db/main/DB/from_linux', 'Output_'+str(date.today())+'.xlsx']
    check_folder = None
    while check_folder != 'All are correct':
        print('\nFolder location of database file is set as: \n' + data_location_name[0] + '\n')
        print('Database file name is set as: \n' + data_location_name[1] + '\n')
        print('Output file destination is set as \n' + data_location_name[2] + '\n')
        print('Output file name is set as \n' + data_location_name[3] + '\n')
        check_folder = ask_option("Do you want to change any options?",
                                  ['Database Folder', 'Database File', 'Output File Destination', 'Output File Name','All are correct'])
        if check_folder == 'Database Folder':
            print('Folder location of database file is set as: \n' + data_location_name[0] + '\n')
            data_location_name[0] = input ("Please enter destination folder: ")
        elif check_folder == 'Database File':
            print('Database file name is set as: \n' + data_location_name[1] + '\n')
            data_location_name[1] = input ("Please input correct database file name: ")
        elif check_folder == 'Output File Destination':
            print('Output file destination is set as: \n' + data_location_name[2] + '\n')
            data_location_name[2]= input("Please input correct output file destination: ")
        elif check_folder == 'Output File Name':
            print('Output file name is set as: \n' + data_location_name[3] + '\n')
            file_name = input("Please input correct output file name (without date and .xlsx): ")
            data_location_name[3] =  file_name+ str(date.today()) + '.xlsx'
    path = os.path.join(data_location_name[0], data_location_name[1])
    ex_path = os.path.join(data_location_name[2], data_location_name[3])
    conn = sqlite3.connect(path)
    cursor = conn.cursor()
    tables_to_print = []
    for table in db_tables():
        check = table_check(cursor, table)
        if check:
            tables_to_print.append(table)
    if tables_to_print == []:
        print ("Selected Database has no tables. Please re-start and edit database file")
        return
    else:
        writer = pd.ExcelWriter(ex_path, engine='xlsxwriter')
        for table in tables_to_print:
            to_print = ask_y_n("Do you want to print "+table)
            if to_print:
                modules = table_dicts.table_module_dict(table)
                columns = []
                if modules == []:
                    columns = table_dicts.db_dict(table, modules)
                else:
                    for module in modules:
                        cols = table_dicts.db_dict(table, module)
                        columns = columns + cols
                col_list = table_dicts.create_col_list(columns)
                sql = ('SELECT ' + ", ".join(col_list) + " FROM '" + table + "'")
                df = pd.read_sql(sql, conn)
                df.to_excel(writer, sheet_name=table)
    writer.save()
    print ("Data file has been created at: "+ex_path)