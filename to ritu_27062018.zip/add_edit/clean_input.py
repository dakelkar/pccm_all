to_do = {'55/17', '257/16', '270/14', '222/12', '443/15', '283/12', '651/15', '593/15', '574/15', '571/15', '55/10',
         '264/12', '518/16','201/17','346/17','555/16','334/17','351/17','297/17','367/17','335/17',
         '607/16','434/16','517/16','427/15','312/16','506/16','880/16','72/16','297/16', '268/15', '630/16', '3/15',
         '460/16', '362/13', '535/14', '279/13', '46/13', '174/12', '329/16', '80/14', '259/17', '312/17', '201/13',
         '136/14', '346/16'}
import sqlite3
import os
import pandas as pd
folders = "d:/repos/pccm_db/main/DB/from_linux/"
file = 'PCCM_BreastCancerDB_all_data_clean_28052018.db'
path_all = os.path.join(folders, file)
os.path.isfile(path_all)
conn_all = sqlite3.connect(path_all)
cursor_all = conn_all.cursor()
table = ["Patient_Information_History", "Follow_up_Data", "HormoneTherapy_Recurrence_Survival", "Radiotherapy", "Surgery_Report"]
x = []
for index in table:
    sql = "SELECT File_number FROM '"+index+"'"
    df = pd.read_sql(sql, conn_all)
    df_list= list(df['File_number'])
    df_del = []
    for i in df_list:
        if i not in to_do:
            df_del.append(i)
    if df_del != []:
        x = x + df_del
        for j in df_del:
            sql = "DELETE FROM '"+index+"' WHERE File_number = '"+j+"'"
            cursor_all.execute(sql)
conn_all.commit()


# delete duplicate rows
table = 'x'
sql = ('DELETE FROM '+table+' WHERE rowid NOT IN (SELECT MIN(rowid)FROM '+table+' GROUP BY File_number)')
cursor_all.execute(sql)